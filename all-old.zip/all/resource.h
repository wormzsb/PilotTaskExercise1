//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DlgResource.rc
//
#pragma once

#define IDD_PAUSE                     101
#define ID_NEXT                       1000
#define ID_CANCEL      								1001
#define ID_CONTINUE     							1002

